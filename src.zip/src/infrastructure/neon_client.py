# import psycopg2
# from psycopg2.extras import execute_values


# class NeonClient:
#     def __init__(self, db_config):
#         self.conn = psycopg2.connect(db_config["url"])
#         self.conn.autocommit = True

#     def insert_dataframe(self, df, table_name):
#         if df.empty:
#             return

#         df = df.where(df.notnull(), None)

#         cols = list(df.columns)
#         values = [tuple(x) for x in df.to_numpy()]

#         query = f"""
#         INSERT INTO {table_name} ({', '.join(cols)})
#         VALUES %s
#         ON CONFLICT (date, lab_sample_id)
#         DO UPDATE SET
#         {', '.join([f"{col}=EXCLUDED.{col}" for col in cols if col not in ['date', 'lab_sample_id']])}
#         """

#         with self.conn.cursor() as cur:
#             execute_values(cur, query, values)

#     def close(self):
#         self.conn.close()

import psycopg2
from psycopg2.extras import execute_values
import pandas as pd


class NeonClient:
    def __init__(self, db_config):
        self.conn = psycopg2.connect(db_config["url"])
        self.conn.autocommit = True

    def insert_dataframe(self, df, table_name, conflict_cols=None):
        if df.empty:
            return

        df = df.copy()

        #  ensure timezone-aware date
        if "date" in df.columns:
            # ✅ ALWAYS force single column (even if duplicate existed earlier)
            date_col = df.loc[:, "date"]

            # if multiple columns → take first
            if isinstance(date_col, pd.DataFrame):
                date_col = date_col.iloc[:, 0]

            df["date"] = pd.to_datetime(date_col, errors="coerce", utc=True)

        df = df.where(df.notnull(), None)

        cols = list(df.columns)
        values = [tuple(x) for x in df.to_numpy()]

        #  dynamic conflict columns
        conflict_cols = conflict_cols or ["date"]

        update_cols = [col for col in cols if col not in conflict_cols]

        query = f"""
        INSERT INTO {table_name} ({', '.join(cols)})
        VALUES %s
        ON CONFLICT ({', '.join(conflict_cols)})
        DO UPDATE SET
        {', '.join([f"{col}=EXCLUDED.{col}" for col in update_cols])}
        """

        with self.conn.cursor() as cur:
            execute_values(cur, query, values)

    def close(self):
        self.conn.close()